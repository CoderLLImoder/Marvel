//
//  DetailViewController.swift
//  MDHomework
//
//  Created by Илья Капёрский on 21.10.2023.
//

import UIKit

final class DetailViewController: UIViewController {
    
    private enum CustomConstraints: CGFloat {
        case padding10 = 10
        case padding20 = 20
        case padding40 = 40
        case padding240 = 240
    }
    
    
    private lazy var rect: UIView = {
        let rect = UIView()
        rect.layer.cornerRadius = 10
        rect.backgroundColor = .systemFill
        rect.clipsToBounds = true
        rect.translatesAutoresizingMaskIntoConstraints = false
        return rect
    }()
    
    private lazy var label: UILabel = {
        let label = UILabel()
        label.textColor = .label
        label.text = "Bluetooth"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViewSettings()
        setupHierarchy()
        setupLayout()
    }
    
    //MARK: - Setup
    
    private func setupHierarchy() {
        view.addSubview(rect)
        view.addSubview(label)
    }
    
    private func setupLayout() {
        NSLayoutConstraint.activate([
            rect.leftAnchor.constraint(equalTo: view.leftAnchor, constant: CustomConstraints.padding20.rawValue),
            rect.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: CustomConstraints.padding10.rawValue),
            rect.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -CustomConstraints.padding20.rawValue),
            rect.heightAnchor.constraint(equalToConstant: CustomConstraints.padding240.rawValue),
            
            label.leftAnchor.constraint(equalTo: rect.leftAnchor, constant: CustomConstraints.padding40.rawValue),
            label.centerYAnchor.constraint(equalTo: rect.centerYAnchor)
            ])
    }
    
    private func setupViewSettings() {
        view.backgroundColor = .systemBackground
        title = "Bluetooth"
        navigationController?.navigationBar.prefersLargeTitles = true
    }
}

