//
//  AlamofireMethods.swift
//  MDHomework
//
//  Created by Илья Капёрский on 20.10.2023.
//

import Foundation
import Alamofire

func fetchSeries() -> [Character] {
    let request = AF.request("https://gateway.marvel.com/v1/public/characters?ts=1&apikey=f85865d962e7db44477b478f45ac83ed&hash=4e4a85782dc48dd3f18232688703eed2")
    var result = [Character]()
    request.responseDecodable(of: CharacterDataWrapper.self) { (data) in
        guard let char = data.value else { return }
        let characters = char.data?.results
        result = characters!
    }
    
    return result
}
